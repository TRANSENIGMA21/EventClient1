package com.cts.util;

import javax.ws.rs.core.UriBuilder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class TestApp {

	public static void main(String[] args) {
		
	/*	calling  service through a java class*/
		
		 ClientConfig clientConfig = new DefaultClientConfig();
			Client client=Client.create(clientConfig);
			WebResource service = client.resource(UriBuilder.fromUri("http://localhost:9090/ImageDemo/").build());
	     ClientResponse cresponse = 
		    		service.path("rest").path("/ImageService/GetData/3256;eventName=training")
		    		.type("text/plain")
		    	    .get(ClientResponse.class); 
	     
	     System.out.println(cresponse.getCookies()); 
		    System.out.println(cresponse); 
		

	}

}
